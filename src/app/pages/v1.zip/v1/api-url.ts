export class APIURL {
    public static apiURL: string = "https://auliaausath.site/mobile/_api_/android_dev/";     
    public static apiPayment: string = "https://auliaausath.site/mobile/_api_/payment/";    
}